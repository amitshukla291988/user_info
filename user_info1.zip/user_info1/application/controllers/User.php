<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Controller {
	public function __constructor(){
		
	}
	
	public function index()
	{	
		$this->load->view('admin/index');
	}
	public function check_auth(){
		if(!isset($_SESSION['id'])){
			redirect('user/index');
		}
	}
	public function login(){
		
		extract($_POST);
		$this->load->database();
		$qry=$this->db->query("select id from admin where name='".$username."' and pwd='".$password."'")->row();
		if($qry){
			//$this->load->view('admin/userInfo');
			$_SESSION['id']=$qry->id ;
			redirect('user/userInfo');
		}else{
			$data['msg']='Wrong user name and password';
			$this->load->view('admin/index',$data);
		}
		
	}

	public function userInfo(){
		$this->check_auth();
		$this->load->database();
		$user=$this->db->query("select id,name,contactNo,email from user where status=1")->result();
		$data['main_content']='userInfo' ;
		$data['user_list']=$user;
		$res['data']=$data ;
		$this->load->view('admin/template',$res);
	}

	public function userDetail($id=''){
		$this->check_auth();
		$this->load->database();
		if($id!=''){
		$qry=$this->db->query("select ud.id,ud.userId, ud.title,ud.description, ud.document, c.name as categoryName from user_detail as ud inner join category as c on c.id=ud.categoryId where ud.userId=$id");
		$qry_num=$qry->num_rows();
		if($qry_num > 0){
			$data['user_data']=$qry->result();
		}else{
			$data['user_data']='';
		}
		}else{
			$data['user_data']='';	
		}
		$data['userId']=$id;
		$data['main_content']='user_detail' ;
		$res['data']=$data;
		$this->load->view('admin/template',$res);
	}
	 public function do_upload($file,$path) { 
         $config['upload_path']   = $path ; 
         $config['allowed_types'] = 'gif|jpg|png|doc|pdf|docx'; 
         $config['max_size']      = 8000; 
         $config['max_width']     = 1024; 
         $config['max_height']    = 768;  
         $this->load->library('upload', $config);
		$msg=0;	
         if ( ! $this->upload->do_upload($file)) {
            $data = array('error' => $this->upload->display_errors()); 
            //$this->load->view('upload_form', $error); 
            $msg=1;
         }
			
         else { 
            $data = array('upload_data' => $this->upload->data()); 
            //$this->load->view('upload_success', $data); 
            $msg=2;
         } 
           return $msg;
      } 

      public function upload(){
      $this->check_auth();
      $this->load->database();
      extract($_POST);

      $document=isset($_FILES['file1']['name'])?$_FILES['file1']['name']:'';
      $userId=isset($userId)?$userId:'';
      $title=isset($title)?$title:'';
      $editor1=isset($editor1)?$editor1:'';
      $categoryId=isset($categoryId)?$categoryId:'';
 	  $flag=0;
 	  if($document!=''){
 	  	$path='./assets/upload/';
 	  	/*$path1='../assets/upload/';
 	  	$filename=$path1.str_replace(" ", "_", $document) ;
 	  	 unlink($filename);	*/  	
 	  	$d=$this->do_upload('file1',$path);
 	  	if($d==2){
 	  		 $qry="insert into user_detail(userId,categoryId,title,description,document)values($userId,$categoryId,'$title','$editor1','$document')";
 	  		 $this->db->query($qry);
 	  		 $flag=1;
 	  	} else {
 	  		$flag=2;
 	  	}
 	  
 	  }else{
 	  	$qry="insert into user_detail(userId,categoryId,title, description, document)values($userId,$categoryId,'$title','$editor1','$document')";
 	  	
 	  	$this->db->query($qry);
 	  	$flag=1;
 	  }
     
     echo $flag;
      }

      public function getDate(){
      	$this->check_auth();
      	$this->load->database();
		extract($_POST);
		
		$qry=$this->db->query("select ud.id,ud.userId, ud.title,ud.description, ud.document, c.name as categoryName from user_detail as ud inner join category as c on c.id=ud.categoryId where ud.userId=$userId");
		$qry_num=$qry->num_rows();
		if($qry_num > 0){
			$data['user_data']=$qry->result();
		}else{
			$data['user_data']='';
		}
		
		$res['data']=$data;
		$this->load->view('admin/update_userdetail',$res);

      }

      public function logout(){
     	unset($_SESSION['id']);
     	$this->load->view('admin/index');
      }
}

