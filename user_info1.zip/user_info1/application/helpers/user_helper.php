<?php 

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function getCategory(){
        $ci=& get_instance();
        $ci->load->database(); 

        $sql = "select * from category"; 
        $query = $ci->db->query($sql);
        return $row = $query->result();
   }















?>