<!DOCTYPE html>
<html>
<head>
	<title>User History</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

	<script src="https://cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
	<style type="text/css">
		.st{
			margin-bottom: 0px;
		}
		.dataTables_filter {
		display: none; 
		}
	</style>

</head>
<body>
<nav class="navbar navbar-default st">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="<?php echo base_url(); ?>user/userInfo">User</a></li>
     <!--  <li><a href="#">User</a></li> -->
     
    </ul>
    <div style="margin: 15px ;"><a href="<?php echo base_url().'user/logout' ; ?>" class="pull-right">Log Out</a></div>
    </div>
</nav>




