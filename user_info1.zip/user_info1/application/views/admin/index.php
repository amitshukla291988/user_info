<!DOCTYPE html>
<html>
<head>
    <title>admin</title>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <link rel="stylesheet" href="<?php echo 'http://localhost/user_info1/assets/css/style.css' ; ?>">   
</head>
<style type="text/css">
    .login{
        margin-top:10%;
    }
    .st{
        margin-bottom:15px;
    }
</style>
<body>



<div class="wrapper login">

    <form class="form-signin" method="post" action="<?php echo base_url(); ?>user/login" id="signup">  
    <?php  if(isset($msg)){ ?>
    <div class="alert alert-danger"><?php echo $msg ; ?></div>
    <?php } ?>
      <h2 class="form-signin-heading st">Admin Login</h2>
      <input type="text" class="form-control" name="username" id="username" placeholder="Enter user name" autocomplete="" />
      <div class="text-danger st" id="errMsg_user"></div>
      <input type="password" class="form-control" name="password" id="password" placeholder="Enter Password" /> 
        <div class="text-danger st" id="errMsg_pwd"></div> 
        
      <label class="checkbox">
        <!-- <input type="checkbox" value="remember-me" id="rememberMe" name="rememberMe"> Remember me -->
      </label>
      <button class="btn btn-lg btn-primary btn-block" type="submit">Login</button>   
    </form>
  </div>
<script type="text/javascript">
/*var baseUrl='<?php echo base_url(); ?>index.php/' ;
    $('#signup').submit(function(e){
         e.preventDefault();
        var user=$('#username').val();
        var pwd=$('#password').val();
       
        if(user==''){  
            $('#errMsg_user').html('Please enter user name.') ;
            return false;
        }else if(pwd==''){
            $('#errMsg_user').html('');
            $('#errMsg_pwd').html('Please enter password.') ;
            return false;
        }else{
            $('#errMsg_user').html('');
            $('#errMsg_pwd').html('');
            var dataStr=$(this).serialize();
            $.ajax({
                type:"POST",
                url:baseUrl+"user/login/",
                data:dataStr,
                success:function(response){
                   if(response==1){

                   }else{

                   }
                }
            })
            return true;
        }

        return false;
    });
   */
</script>
</body>
</html>
