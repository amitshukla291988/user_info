<?php 
$this->load->view('admin/header');

$this->load->view('admin/'.$data['main_content'],$data);

$this->load->view('admin/footer');
?>