<?php   
//echo "<pre>";
//print_r($data);
//exit;
	if($data['user_data']!=''){
  foreach ($data['user_data'] as $value) { ?>
    
      <tr>
     
        <td><?php echo $value->title ; ?></td>
        <td><?php echo $value->description ; ?></td>
        <td><?php echo $value->categoryName ; ?></td>
        <td><?php if($value->document!=''){ ?>
             <a href="http://localhost/user_info1/assets/upload/<?php echo str_replace(" ", "_", $value->document) ; ?>"><span class="glyphicon glyphicon-download"></span> <?php echo $value->document ; ?></a>

          <?php } ?></td>
        <!-- <td><a href="<?php echo base_url(); ?>user/userDetail/<?php echo $value->id ; ?>" class="btn btn-primary">View History</a></td> -->
      </tr>
    <?php   } }else{ ?>
    <tr>
    	<td colspan="4">Data not found.</td>
    </tr>
    <?php }
?>