<div class="container">
  <h2>User </h2>
          
  <table class="table" id="example">
    <thead>
      <tr>
        <th >Name</th>
        <th >Email</th>
        <th >Contact No</th>
        <th >Action</th>
      </tr>
    </thead>
    <tbody>
<?php   
  if($user_list!=''){
  foreach ($user_list as $value) { ?>
    
 
      <tr>
     
        <td><?php echo $value->name ; ?></td>
        <td><?php echo $value->email ; ?></td>
        <td><?php echo $value->contactNo ; ?></td>
        <td><a href="<?php echo base_url(); ?>user/userDetail/<?php echo $value->id ; ?>" class="btn btn-primary">View History</a></td>
      </tr>
    <?php   }
  }else{ ?>
    <tr>
      <td colspan="4">Data not found</td>
    </tr>

  <?php }
?>
    </tbody>
  </table>
</div>