<div class="container">
  <h2>User Detail</h2>
  	<div  id="succ"></div>
  	
  	
      <a href="" class="btn btn-primary pull-right" data-toggle="modal" data-target="#myModal">Add History</a>    
  <table class="table" id="example">
    <thead>
      <tr>
      
        <th >Title</th>
        <th >Description</th>
        <th >Category</th>
        <th >Document</th>
        
       <!--  <th >Action</th> -->
      </tr>
    </thead>
    <tbody id="update_data">
<?php 

	if($user_data!=''){
  foreach ($user_data as $value) { ?>
    
      <tr>
     
        <td><?php echo $value->title ; ?></td>
        <td><?php echo $value->description ; ?></td>
        <td><?php echo $value->categoryName ; ?></td>
        <td>
        <?php if($value->document!=''){ ?>
        		 <a href="http://localhost/user_info1/assets/upload/<?php echo str_replace(" ", "_", $value->document) ; ?>"><span class="glyphicon glyphicon-download"></span> <?php echo $value->document ; ?></a>

        	<?php } ?>
       
        </td>

        <!-- <td><a href="<?php echo base_url(); ?>user/userDetail/<?php echo $value->id ; ?>" class="btn btn-primary">View History</a></td> -->
      </tr>
    <?php   } }else{ ?>
    <tr>
    	<td colspan="4">Data not found.</td>
    </tr>
    <?php }
?>
    </tbody>
  </table>
</div>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add History</h4>
      </div>
      <div class="modal-body">
		<form id="userHistory" method="post" enctype="multipart/form-data" >
		<input type="hidden" name="userId" id="userId" value="<?php echo $data['userId'] ; ?>">
		<div class="form-group">
		<label for="title">Title:</label>
		<input type="text" class="form-control" id="title" name="title">
		 <div class="text-danger" id="errMsg_title"></div>
		</div>
  <?php $t=getCategory();  ?>
    <div class="form-group">
    <label for="title">Category:</label>
     <select class="form-control" id="categoryId" name="categoryId">
      <option value="">Select One</option>
      <?php 
      foreach ($t as $value1) { ?>
        <option value="<?php echo $value1->id ; ?>"><?php echo $value1->name ; ?></option>
      <?php } ?>
       
    </select>
     
    </div> 
		<div class="form-group" >
		<label for="pwd">Description:</label>
		<textarea name="editor1" id="editor1"></textarea>
		<script>
			CKEDITOR.replace( 'editor1' );
		</script>
		</div>
		<div class="form-group">
		<label for="usr">Upload:</label>
		<input type="file" class="form-control" id="file1" name="file1">
		</div>
		<div class="form-group">
		<label for="usr"></label>
		<input type="submit" class="btn btn-primary" value="submit" id="submit">
		</div>
		</form>
      </div>
     
    </div>

  </div>
</div>
<script type="text/javascript">

var baseUrl='<?php echo base_url(); ?>' ;
    $('#userHistory').submit(function(e){
         e.preventDefault();
         for ( instance in CKEDITOR.instances ) {
        CKEDITOR.instances[instance].updateElement();
    }
        var form = $("#userHistory")[0];
       
        var user=$('#title').val();
        
        if(user==''){  
            $('#errMsg_title').html('Please enter title.') ;
            return false;
        } else {
            $('#errMsg_user').html('');
            var userId=$('#userId').val();
            var dataStr=new FormData(form);
            $('#succ').removeClass('');
             $('#succ').html('');
            $('#succ').show();
            $.ajax({
                type:"POST",
                url:baseUrl+"user/upload/",
                data:dataStr,
                contentType: false,
	            processData: false,
	            
                success:function(response){
                   if(response==1){
                   		$('#succ').addClass('alert alert-success').html('Successfully upload history');

                   }else{
                   	$('#succ').addClass('alert alert-danger').html('Error occurred');
                   }
                   
                   $('.modal').trigger('click');
                   $("#userHistory").trigger('reset');

                   CKEDITOR.instances.editor1.setData('');
                   update_userdtail(userId);
                    setTimeout(function(){
                	$('#succ').hide();
                },5000);
                }
               
            })
            return true;
        }

        return false;
    });

    function update_userdtail(id){
    	
    	$.ajax({
                type:"POST",
                url:baseUrl+"user/getDate/",
                data:{userId:id},           
                success:function(response){
                	$('#update_data').html(response);
                }
            });
    }
   
</script>